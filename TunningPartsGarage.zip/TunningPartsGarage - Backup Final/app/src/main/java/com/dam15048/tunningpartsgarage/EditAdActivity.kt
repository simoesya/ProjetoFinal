package com.dam15048.tunningpartsgarage

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class EditAdActivity : AppCompatActivity() {

    private lateinit var imageEditAdPreview: ImageView
    private lateinit var buttonEditChooseImage: Button
    private lateinit var buttonEditChooseLocationMap: Button
    private lateinit var editEditAdTitle: EditText
    private lateinit var spinnerEditCategory: Spinner
    private lateinit var editEditAdDescription: EditText
    private lateinit var editEditAdPrice: EditText
    private lateinit var editEditAdLocation: EditText
    private lateinit var editEditAdPhone: EditText
    private lateinit var buttonSaveAdChanges: Button

    private lateinit var db: FirebaseFirestore

    private var adId: String = ""
    private var selectedImageUri: Uri? = null
    private var oldImageUriText: String = "no_image"

    private var selectedLatitude: Double? = null
    private var selectedLongitude: Double? = null

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            imageEditAdPreview.setImageURI(uri)
            imageEditAdPreview.setPadding(0, 0, 0, 0)
        }
    }

    private val mapPicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val latitude = result.data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val longitude = result.data?.getDoubleExtra("longitude", 0.0) ?: 0.0
            val locationName = result.data?.getStringExtra("locationName")
                ?: getString(R.string.map_selected_location_generic)

            selectedLatitude = latitude
            selectedLongitude = longitude

            editEditAdLocation.setText(locationName)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_edit_ad)

        db = FirebaseFirestore.getInstance()

        imageEditAdPreview = findViewById(R.id.imageEditAdPreview)
        buttonEditChooseImage = findViewById(R.id.buttonEditChooseImage)
        buttonEditChooseLocationMap = findViewById(R.id.buttonEditChooseLocationMap)
        editEditAdTitle = findViewById(R.id.editEditAdTitle)
        spinnerEditCategory = findViewById(R.id.spinnerEditCategory)
        editEditAdDescription = findViewById(R.id.editEditAdDescription)
        editEditAdPrice = findViewById(R.id.editEditAdPrice)
        editEditAdLocation = findViewById(R.id.editEditAdLocation)
        editEditAdPhone = findViewById(R.id.editEditAdPhone)
        buttonSaveAdChanges = findViewById(R.id.buttonSaveAdChanges)

        setupCategorySpinner()

        adId = intent.getStringExtra("adId") ?: ""

        if (adId.isEmpty()) {
            Toast.makeText(this, getString(R.string.ad_without_id), Toast.LENGTH_LONG).show()
            finish()
            return
        }

        loadAdFromFirebase()

        buttonEditChooseImage.setOnClickListener {
            imagePicker.launch("image/*")
        }

        buttonEditChooseLocationMap.setOnClickListener {
            val intent = Intent(this, MapPickerActivity::class.java)
            mapPicker.launch(intent)
        }

        buttonSaveAdChanges.setOnClickListener {
            saveChanges()
        }
    }

    private fun setupCategorySpinner() {
        val categories = listOf(
            getString(R.string.cat_wheels),
            getString(R.string.cat_suspension),
            getString(R.string.cat_exhaust),
            getString(R.string.cat_brakes),
            getString(R.string.cat_engine),
            getString(R.string.cat_lights),
            getString(R.string.cat_interior),
            getString(R.string.cat_bodykits)
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            categories
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerEditCategory.adapter = adapter
    }

    private fun loadAdFromFirebase() {
        db.collection("ads")
            .document(adId)
            .get()
            .addOnSuccessListener { document ->
                if (!document.exists()) {
                    Toast.makeText(this, "Anúncio não encontrado", Toast.LENGTH_LONG).show()
                    finish()
                    return@addOnSuccessListener
                }

                val ad = document.toObject(Ad::class.java)

                if (ad == null) {
                    Toast.makeText(this, "Erro ao carregar anúncio", Toast.LENGTH_LONG).show()
                    finish()
                    return@addOnSuccessListener
                }

                ad.id = document.id
                fillFieldsWithAd(ad)
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "Erro ao carregar anúncio: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
    }

    private fun fillFieldsWithAd(ad: Ad) {
        editEditAdTitle.setText(ad.title)
        editEditAdDescription.setText(ad.description)
        editEditAdPrice.setText(ad.price)
        editEditAdLocation.setText(ad.location)
        editEditAdPhone.setText(ad.phone)

        oldImageUriText = ad.imageUri

        val categoryName = getCategoryNameFromId(ad.categoryId)
        val categoryPosition = getCategoryPosition(categoryName)
        spinnerEditCategory.setSelection(categoryPosition)

        if (oldImageUriText != "no_image") {
            imageEditAdPreview.setImageURI(Uri.parse(oldImageUriText))
            imageEditAdPreview.setPadding(0, 0, 0, 0)
        } else {
            imageEditAdPreview.setImageResource(android.R.drawable.ic_menu_camera)
        }
    }

    private fun saveChanges() {
        val title = editEditAdTitle.text.toString().trim()
        val selectedCategory = spinnerEditCategory.selectedItem.toString()
        val categoryId = getCategoryId(selectedCategory)
        val description = editEditAdDescription.text.toString().trim()
        val price = editEditAdPrice.text.toString().trim()
        val location = editEditAdLocation.text.toString().trim()
        val phone = editEditAdPhone.text.toString().trim()

        if (
            title.isEmpty() ||
            description.isEmpty() ||
            price.isEmpty() ||
            location.isEmpty() ||
            phone.isEmpty()
        ) {
            Toast.makeText(
                this,
                getString(R.string.fill_all_fields),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        buttonSaveAdChanges.isEnabled = false
        buttonSaveAdChanges.text = getString(R.string.saving)

        val finalImageUriText = selectedImageUri?.toString() ?: oldImageUriText

        val updatedData = hashMapOf<String, Any>(
            "title" to title,
            "categoryId" to categoryId,
            "description" to description,
            "price" to price,
            "location" to location,
            "phone" to phone,
            "imageUri" to finalImageUriText
        )

        if (selectedLatitude != null && selectedLongitude != null) {
            updatedData["latitude"] = selectedLatitude!!
            updatedData["longitude"] = selectedLongitude!!
        }

        db.collection("ads")
            .document(adId)
            .update(updatedData)
            .addOnSuccessListener {
                Toast.makeText(this, "Anúncio editado com sucesso", Toast.LENGTH_SHORT).show()

                val resultIntent = Intent()
                resultIntent.putExtra("editedAdId", adId)
                resultIntent.putExtra("editedAdTitle", title)

                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            }
            .addOnFailureListener { error ->
                buttonSaveAdChanges.isEnabled = true
                buttonSaveAdChanges.text = getString(R.string.save_changes)

                Toast.makeText(
                    this,
                    "Erro ao editar anúncio: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun getCategoryId(categoryName: String): String {
        return when (categoryName) {
            getString(R.string.cat_wheels) -> "wheels"
            getString(R.string.cat_suspension) -> "suspension"
            getString(R.string.cat_exhaust) -> "exhaust"
            getString(R.string.cat_brakes) -> "brakes"
            getString(R.string.cat_engine) -> "engine"
            getString(R.string.cat_lights) -> "lights"
            getString(R.string.cat_interior) -> "interior"
            getString(R.string.cat_bodykits) -> "bodykits"
            else -> "wheels"
        }
    }

    private fun getCategoryNameFromId(categoryId: String): String {
        return when (categoryId) {
            "wheels" -> getString(R.string.cat_wheels)
            "suspension" -> getString(R.string.cat_suspension)
            "exhaust" -> getString(R.string.cat_exhaust)
            "brakes" -> getString(R.string.cat_brakes)
            "engine" -> getString(R.string.cat_engine)
            "lights" -> getString(R.string.cat_lights)
            "interior" -> getString(R.string.cat_interior)
            "bodykits" -> getString(R.string.cat_bodykits)
            else -> getString(R.string.cat_wheels)
        }
    }

    private fun getCategoryPosition(categoryName: String): Int {
        return when (categoryName) {
            getString(R.string.cat_wheels) -> 0
            getString(R.string.cat_suspension) -> 1
            getString(R.string.cat_exhaust) -> 2
            getString(R.string.cat_brakes) -> 3
            getString(R.string.cat_engine) -> 4
            getString(R.string.cat_lights) -> 5
            getString(R.string.cat_interior) -> 6
            getString(R.string.cat_bodykits) -> 7
            else -> 0
        }
    }
}