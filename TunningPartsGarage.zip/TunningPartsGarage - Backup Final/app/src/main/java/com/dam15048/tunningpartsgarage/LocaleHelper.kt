package com.dam15048.tunningpartsgarage

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {

    fun setLocale(context: Context, languageCode: String): Context {
        val locale = when (languageCode) {
            "en", "en-GB" -> Locale("en", "GB")
            "es", "es-ES" -> Locale("es", "ES")
            else -> Locale("pt", "PT")
        }

        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        return context.createConfigurationContext(config)
    }
}