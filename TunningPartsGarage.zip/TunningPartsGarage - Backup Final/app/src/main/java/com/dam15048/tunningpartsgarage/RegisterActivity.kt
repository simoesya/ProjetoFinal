package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editRegisterEmail: EditText
    private lateinit var editRegisterPassword: EditText
    private lateinit var editConfirmPassword: EditText
    private lateinit var buttonCreateAccount: Button
    private lateinit var buttonBackLogin: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        editName = findViewById(R.id.editName)
        editRegisterEmail = findViewById(R.id.editRegisterEmail)
        editRegisterPassword = findViewById(R.id.editRegisterPassword)
        editConfirmPassword = findViewById(R.id.editConfirmPassword)
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount)
        buttonBackLogin = findViewById(R.id.buttonBackLogin)

        buttonCreateAccount.setOnClickListener {
            createAccount()
        }

        buttonBackLogin.setOnClickListener {
            finish()
        }
    }

    private fun createAccount() {
        val name = editName.text.toString().trim()
        val email = editRegisterEmail.text.toString().trim()
        val password = editRegisterPassword.text.toString().trim()
        val confirmPassword = editConfirmPassword.text.toString().trim()

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.fill_all_fields),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (password != confirmPassword) {
            Toast.makeText(
                this,
                getString(R.string.passwords_not_match),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(
                this,
                getString(R.string.password_min_length),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                val user = auth.currentUser

                if (user != null) {
                    saveUserInFirestore(user.uid, name, email)
                }
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "${getString(R.string.register_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun saveUserInFirestore(uid: String, name: String, email: String) {
        val userData = hashMapOf(
            "uid" to uid,
            "name" to name,
            "email" to email,
            "isPremium" to false,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("users")
            .document(uid)
            .set(userData)
            .addOnSuccessListener {
                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

                sharedPreferences.edit()
                    .putString("userName", name)
                    .putString("userEmail", email)
                    .putString("userId", uid)
                    .putBoolean("isPremium", false)
                    .apply()

                Toast.makeText(
                    this,
                    getString(R.string.register_success),
                    Toast.LENGTH_SHORT
                ).show()

                val intent = Intent(this, MainMenuActivity::class.java)
                intent.putExtra("userEmail", email)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "${getString(R.string.save_data_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}