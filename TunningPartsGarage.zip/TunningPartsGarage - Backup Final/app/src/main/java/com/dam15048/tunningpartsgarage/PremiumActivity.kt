package com.dam15048.tunningpartsgarage

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class PremiumActivity : AppCompatActivity() {

    private lateinit var textPremiumStatus: TextView
    private lateinit var buttonActivatePremium: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_premium)

        textPremiumStatus = findViewById(R.id.textPremiumStatus)
        buttonActivatePremium = findViewById(R.id.buttonActivatePremium)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        updatePremiumStatus()

        buttonActivatePremium.setOnClickListener {
            activatePremium()
        }
    }

    private fun updatePremiumStatus() {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            textPremiumStatus.text = getString(R.string.premium_no_session)
            buttonActivatePremium.text = getString(R.string.premium_login_needed)
            buttonActivatePremium.isEnabled = false
            return
        }

        textPremiumStatus.text = getString(R.string.premium_checking)

        db.collection("users")
            .document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                val isPremium = document.getBoolean("isPremium") ?: false

                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

                sharedPreferences.edit()
                    .putBoolean("isPremium", isPremium)
                    .apply()

                if (isPremium) {
                    textPremiumStatus.text = getString(R.string.premium_active)
                    buttonActivatePremium.text = getString(R.string.premium_already_active)
                    buttonActivatePremium.isEnabled = false
                } else {
                    textPremiumStatus.text = getString(R.string.premium_free)
                    buttonActivatePremium.text = getString(R.string.premium_plan)
                    buttonActivatePremium.isEnabled = true
                }
            }
            .addOnFailureListener {
                textPremiumStatus.text = getString(R.string.premium_free)
                buttonActivatePremium.text = getString(R.string.premium_plan)
                buttonActivatePremium.isEnabled = true
            }
    }

    private fun activatePremium() {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            Toast.makeText(
                this,
                getString(R.string.login_required),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        buttonActivatePremium.isEnabled = false
        buttonActivatePremium.text = getString(R.string.premium_activating)

        val premiumData = hashMapOf<String, Any>(
            "isPremium" to true,
            "premiumPrice" to "1€/mês",
            "premiumActivatedAt" to System.currentTimeMillis()
        )

        db.collection("users")
            .document(currentUser.uid)
            .set(premiumData, SetOptions.merge())
            .addOnSuccessListener {
                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

                sharedPreferences.edit()
                    .putBoolean("isPremium", true)
                    .apply()

                buttonActivatePremium.animate()
                    .scaleX(1.1f)
                    .scaleY(1.1f)
                    .setDuration(150)
                    .withEndAction {
                        buttonActivatePremium.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(150)
                            .start()
                    }
                    .start()

                Toast.makeText(
                    this,
                    getString(R.string.premium_success),
                    Toast.LENGTH_LONG
                ).show()

                updatePremiumStatus()
            }
            .addOnFailureListener { error ->
                buttonActivatePremium.isEnabled = true
                buttonActivatePremium.text = getString(R.string.premium_plan)

                Toast.makeText(
                    this,
                    "${getString(R.string.premium_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}