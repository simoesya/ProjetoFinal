package com.dam15048.tunningpartsgarage

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PartDetailActivity : AppCompatActivity() {

    private lateinit var imagePart: ImageView
    private lateinit var textHighlighted: TextView
    private lateinit var textPartName: TextView
    private lateinit var textPartDescription: TextView
    private lateinit var textPartPrice: TextView
    private lateinit var textSellerInfo: TextView
    private lateinit var textPremium: TextView
    private lateinit var buttonFavorite: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_part_detail)

        imagePart = findViewById(R.id.imagePart)
        textHighlighted = findViewById(R.id.textHighlighted)
        textPartName = findViewById(R.id.textPartName)
        textPartDescription = findViewById(R.id.textPartDescription)
        textPartPrice = findViewById(R.id.textPartPrice)
        textSellerInfo = findViewById(R.id.textSellerInfo)
        textPremium = findViewById(R.id.textPremium)
        buttonFavorite = findViewById(R.id.buttonFavorite)

        val partId = intent.getStringExtra("partId")
        val part = MockData.parts.find { it.id == partId }

        if (part != null) {
            imagePart.setImageResource(getImageForCategory(part.categoryId))

            textPartName.text = part.name
            textPartDescription.text = part.description
            textPartPrice.text = "Preço: ${part.price}€"

            textSellerInfo.text =
                "Vendedor: ${part.sellerName}\n" +
                        "Localização: ${part.location}\n" +
                        "Contacto: ${part.phone}"

            if (part.isHighlighted) {
                textHighlighted.visibility = View.VISIBLE
            } else {
                textHighlighted.visibility = View.GONE
            }

            if (part.isPremium) {
                textPremium.text = "Anúncio exclusivo Premium Garage"
            } else {
                textPremium.text = "Anúncio disponível para todos os utilizadores"
            }

            buttonFavorite.setOnClickListener {
                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

                val favorites = sharedPreferences
                    .getStringSet("favorites", emptySet())
                    ?.toMutableSet() ?: mutableSetOf()

                favorites.add(part.id)

                sharedPreferences.edit()
                    .putStringSet("favorites", favorites)
                    .apply()

                Toast.makeText(this, "${part.name} adicionado aos favoritos", Toast.LENGTH_SHORT).show()
            }
        } else {
            textHighlighted.visibility = View.GONE
            textPartName.text = "Anúncio não encontrado"
            textPartDescription.text = ""
            textPartPrice.text = ""
            textSellerInfo.text = ""
            textPremium.text = ""
        }
    }

    private fun getImageForCategory(categoryId: String): Int {
        return when (categoryId) {
            "wheels" -> android.R.drawable.ic_menu_gallery
            "suspension" -> android.R.drawable.ic_menu_manage
            "exhaust" -> android.R.drawable.ic_menu_upload
            "brakes" -> android.R.drawable.ic_menu_compass
            "engine" -> android.R.drawable.ic_menu_manage
            "lights" -> android.R.drawable.ic_menu_view
            "interior" -> android.R.drawable.ic_menu_myplaces
            "bodykits" -> android.R.drawable.ic_menu_gallery
            else -> android.R.drawable.ic_menu_gallery
        }
    }
}