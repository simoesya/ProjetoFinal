package com.dam15048.tunningpartsgarage

data class Part(
    val id: String,
    val name: String,
    val categoryId: String,
    val description: String,
    val price: Double,
    val isPremium: Boolean,
    val sellerName: String,
    val location: String,
    val phone: String,
    val isHighlighted: Boolean
)