package com.dam15048.tunningpartsgarage

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PartsListActivity : AppCompatActivity() {

    private lateinit var textCategoryTitle: TextView
    private lateinit var containerParts: LinearLayout

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    private var currentCategoryId: String? = null

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_parts_list)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        textCategoryTitle = findViewById(R.id.textCategoryTitle)
        containerParts = findViewById(R.id.containerParts)

        currentCategoryId = intent.getStringExtra("categoryId")

        if (currentCategoryId != null) {
            textCategoryTitle.text = getCategoryNameFromId(currentCategoryId!!)
        } else {
            textCategoryTitle.text = getString(R.string.ads_title)
        }

        loadFirebaseAds()
    }

    private fun loadMockAds() {
        val filteredParts = MockData.parts.filter { it.categoryId == currentCategoryId }

        for (part in filteredParts) {
            createMockAdCard(part)
        }
    }

    private fun loadFirebaseAds() {
        if (currentCategoryId == null) {
            return
        }

        containerParts.removeAllViews()

        db.collection("ads")
            .whereEqualTo("categoryId", currentCategoryId)
            .get()
            .addOnSuccessListener { result ->

                if (result.isEmpty) {
                    showNoAdsMessage()
                    return@addOnSuccessListener
                }

                for (document in result) {
                    val ad = document.toObject(Ad::class.java)
                    ad.id = document.id
                    createFirebaseAdCard(ad)
                }
            }
            .addOnFailureListener {
                val errorText = TextView(this)
                errorText.text = getString(R.string.firebase_ads_error)
                errorText.setTextColor(0xFFFFFFFF.toInt())
                errorText.textSize = 16f
                errorText.gravity = Gravity.CENTER
                errorText.setPadding(0, 80, 0, 0)

                containerParts.addView(errorText)
            }
    }

    private fun showNoAdsMessage() {
        val emptyText = TextView(this)

        emptyText.text = getString(R.string.no_ads_category)
        emptyText.setTextColor(0xFF888888.toInt())
        emptyText.textSize = 18f
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(0, 180, 0, 0)

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        emptyText.layoutParams = params

        containerParts.addView(emptyText)
    }

    private fun createMockAdCard(part: Part) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(0xFF333333.toInt())
        card.setPadding(12, 12, 12, 12)
        card.gravity = Gravity.CENTER

        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        cardParams.setMargins(0, 0, 0, 20)
        card.layoutParams = cardParams

        val highlightedText = TextView(this)
        highlightedText.text = getString(R.string.ad_highlighted)
        highlightedText.setTextColor(0xFFFFD700.toInt())
        highlightedText.textSize = 14f
        highlightedText.setTypeface(null, android.graphics.Typeface.BOLD)
        highlightedText.gravity = Gravity.CENTER
        highlightedText.setPadding(0, 0, 0, 8)

        if (part.isHighlighted) {
            highlightedText.visibility = View.VISIBLE
        } else {
            highlightedText.visibility = View.GONE
        }

        val imageView = ImageView(this)
        imageView.setImageResource(getImageForCategory(part.categoryId))
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP

        val imageParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            350
        )
        imageView.layoutParams = imageParams

        val textView = TextView(this)

        var text =
            "${part.name}\n" +
                    "${part.price}€\n" +
                    part.location

        if (part.isPremium) {
            text += "\n${getString(R.string.premium)}"
        }

        textView.text = text
        textView.setTextColor(0xFFFFFFFF.toInt())
        textView.textSize = 16f
        textView.gravity = Gravity.CENTER
        textView.setPadding(0, 12, 0, 0)

        card.setOnClickListener {
            showMockAdDetails(part)
        }

        card.addView(highlightedText)
        card.addView(imageView)
        card.addView(textView)

        containerParts.addView(card)
    }

    private fun createFirebaseAdCard(ad: Ad) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(0xFF333333.toInt())
        card.setPadding(12, 12, 12, 12)
        card.gravity = Gravity.CENTER

        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        cardParams.setMargins(0, 0, 0, 20)
        card.layoutParams = cardParams

        val highlightedText = TextView(this)
        highlightedText.text = getString(R.string.ad_highlighted)
        highlightedText.setTextColor(0xFFFFD700.toInt())
        highlightedText.textSize = 14f
        highlightedText.setTypeface(null, android.graphics.Typeface.BOLD)
        highlightedText.gravity = Gravity.CENTER
        highlightedText.setPadding(0, 0, 0, 8)

        if (ad.highlighted) {
            highlightedText.visibility = View.VISIBLE
        } else {
            highlightedText.visibility = View.GONE
        }

        val imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.setBackgroundColor(0xFF222222.toInt())

        val imageParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            350
        )
        imageView.layoutParams = imageParams

        if (ad.imageUri != "no_image") {
            imageView.setImageURI(Uri.parse(ad.imageUri))
        } else {
            imageView.setImageResource(getImageForCategory(ad.categoryId))
        }

        val textView = TextView(this)
        textView.text =
            "${ad.title}\n" +
                    "${ad.price}€\n" +
                    ad.location

        textView.setTextColor(0xFFFFFFFF.toInt())
        textView.textSize = 16f
        textView.gravity = Gravity.CENTER
        textView.setPadding(0, 12, 0, 0)

        card.setOnClickListener {
            checkFavoriteAndShowDetails(ad)
        }

        card.addView(highlightedText)
        card.addView(imageView)
        card.addView(textView)

        containerParts.addView(card)
    }

    private fun showMockAdDetails(part: Part) {
        val highlightedText = if (part.isHighlighted) {
            getString(R.string.yes_text)
        } else {
            getString(R.string.no_text)
        }

        val premiumText = if (part.isPremium) {
            getString(R.string.yes_text)
        } else {
            getString(R.string.no_text)
        }

        val message =
            "${getString(R.string.category_label)}: ${getCategoryNameFromId(part.categoryId)}\n\n" +
                    "${getString(R.string.description_hint)}:\n${part.description}\n\n" +
                    "${getString(R.string.price_text)}: ${part.price}€\n\n" +
                    "${getString(R.string.location_text)}: ${part.location}\n\n" +
                    "${getString(R.string.seller_text)}: ${part.sellerName}\n\n" +
                    "${getString(R.string.contact_text)}: ${part.phone}\n\n" +
                    "${getString(R.string.premium)}: $premiumText\n" +
                    "${getString(R.string.highlighted_text)}: $highlightedText"

        AlertDialog.Builder(this)
            .setTitle(part.name)
            .setMessage(message)
            .setPositiveButton(getString(R.string.close), null)
            .show()
    }

    private fun checkFavoriteAndShowDetails(ad: Ad) {
        val currentUser = auth.currentUser

        if (currentUser == null || ad.id.isEmpty()) {
            showFirebaseAdDetails(ad, false)
            return
        }

        db.collection("users")
            .document(currentUser.uid)
            .collection("favorites")
            .document(ad.id)
            .get()
            .addOnSuccessListener { document ->
                val isFavorite = document.exists()
                showFirebaseAdDetails(ad, isFavorite)
            }
            .addOnFailureListener {
                showFirebaseAdDetails(ad, false)
            }
    }

    private fun showFirebaseAdDetails(ad: Ad, isFavorite: Boolean) {
        val highlightedText = if (ad.highlighted) {
            getString(R.string.yes_text)
        } else {
            getString(R.string.no_text)
        }

        val message =
            "${getString(R.string.category_label)}: ${getCategoryNameFromId(ad.categoryId)}\n\n" +
                    "${getString(R.string.description_hint)}:\n${ad.description}\n\n" +
                    "${getString(R.string.price_text)}: ${ad.price}€\n\n" +
                    "${getString(R.string.location_text)}: ${ad.location}\n\n" +
                    "${getString(R.string.seller_text)}: ${ad.ownerName}\n\n" +
                    "${getString(R.string.contact_text)}: ${ad.phone}\n\n" +
                    "${getString(R.string.highlighted_text)}: $highlightedText"

        val dialog = AlertDialog.Builder(this)
            .setTitle(ad.title)
            .setMessage(message)
            .setPositiveButton(getString(R.string.close), null)

        if (isFavorite) {
            dialog.setNegativeButton(getString(R.string.already_favorite), null)
        } else {
            dialog.setNegativeButton(getString(R.string.add_to_favorites)) { _, _ ->
                addAdToFavorites(ad)
            }
        }

        val alertDialog = dialog.create()

        alertDialog.setOnShowListener {
            if (isFavorite) {
                val favoriteButton = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                favoriteButton.isEnabled = false
                favoriteButton.setTextColor(0xFF888888.toInt())
            }
        }

        alertDialog.show()
    }

    private fun addAdToFavorites(ad: Ad) {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            Toast.makeText(this, getString(R.string.login_required), Toast.LENGTH_SHORT).show()
            return
        }

        if (ad.id.isEmpty()) {
            Toast.makeText(this, getString(R.string.ad_without_id), Toast.LENGTH_SHORT).show()
            return
        }

        val favoriteData = hashMapOf<String, Any>(
            "adId" to ad.id,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("users")
            .document(currentUser.uid)
            .collection("favorites")
            .document(ad.id)
            .set(favoriteData)
            .addOnSuccessListener {
                Toast.makeText(this, getString(R.string.favorite_added), Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun getImageForCategory(categoryId: String): Int {
        return when (categoryId) {
            "wheels" -> R.drawable.jantes
            "suspension" -> R.drawable.suspensao
            "exhaust" -> R.drawable.escape
            "brakes" -> R.drawable.travoes
            "engine" -> R.drawable.motor
            "lights" -> R.drawable.luzes
            "interior" -> R.drawable.interior
            "bodykits" -> R.drawable.bodykit
            else -> R.drawable.jantes
        }
    }

    private fun getCategoryNameFromId(categoryId: String): String {
        return when (categoryId) {
            "wheels" -> getString(R.string.cat_wheels)
            "suspension" -> getString(R.string.cat_suspension)
            "exhaust" -> getString(R.string.cat_exhaust)
            "brakes" -> getString(R.string.cat_brakes)
            "engine" -> getString(R.string.cat_engine)
            "lights" -> getString(R.string.cat_lights)
            "interior" -> getString(R.string.cat_interior)
            "bodykits" -> getString(R.string.cat_bodykits)
            else -> getString(R.string.category_label)
        }
    }
}