package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainMenuActivity : AppCompatActivity() {

    private lateinit var textWelcome: TextView

    private lateinit var buttonCategories: Button
    private lateinit var buttonCreateAd: Button
    private lateinit var buttonMyAds: Button
    private lateinit var buttonFavorites: Button
    private lateinit var buttonPremium: Button
    private lateinit var buttonSettings: Button
    private lateinit var buttonHelp: Button
    private lateinit var buttonAbout: Button

    private var activityLanguage: String = "pt"

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)
        activityLanguage = sharedPreferences.getString("language", "pt") ?: "pt"

        setContentView(R.layout.activity_main_menu)

        textWelcome = findViewById(R.id.textWelcome)

        buttonCategories = findViewById(R.id.buttonCategories)
        buttonCreateAd = findViewById(R.id.buttonCreateAd)
        buttonMyAds = findViewById(R.id.buttonMyAds)
        buttonFavorites = findViewById(R.id.buttonFavorites)
        buttonPremium = findViewById(R.id.buttonPremium)
        buttonSettings = findViewById(R.id.buttonSettings)
        buttonHelp = findViewById(R.id.buttonHelp)
        buttonAbout = findViewById(R.id.buttonAbout)

        updateTexts()

        buttonCategories.setOnClickListener {
            startActivity(Intent(this, CategoriesActivity::class.java))
        }

        buttonCreateAd.setOnClickListener {
            startActivity(Intent(this, CreateAdActivity::class.java))
        }

        buttonMyAds.setOnClickListener {
            startActivity(Intent(this, MyAdsActivity::class.java))
        }

        buttonFavorites.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }

        buttonPremium.setOnClickListener {
            startActivity(Intent(this, PremiumActivity::class.java))
        }

        buttonSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        buttonHelp.setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }

        buttonAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()

        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)
        val currentLanguage = sharedPreferences.getString("language", "pt") ?: "pt"

        if (currentLanguage != activityLanguage) {
            recreate()
            return
        }

        updateTexts()
    }

    private fun updateTexts() {
        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

        val userName = sharedPreferences.getString(
            "userName",
            getString(R.string.default_user)
        ) ?: getString(R.string.default_user)

        textWelcome.text = getString(R.string.welcome_user, userName)

        buttonCategories.text = getString(R.string.categories)
        buttonCreateAd.text = getString(R.string.create_ad)
        buttonMyAds.text = getString(R.string.my_ads)
        buttonFavorites.text = getString(R.string.favorites)
        buttonPremium.text = getString(R.string.premium)
        buttonSettings.text = getString(R.string.settings)
        buttonHelp.text = getString(R.string.help)
        buttonAbout.text = getString(R.string.about)
    }
}