package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SettingsActivity : AppCompatActivity() {

    private lateinit var textAccountInfo: TextView
    private lateinit var textPremiumInfo: TextView

    private lateinit var buttonPortuguese: Button
    private lateinit var buttonEnglish: Button
    private lateinit var buttonSpanish: Button
    private lateinit var buttonLogout: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        textAccountInfo = findViewById(R.id.textAccountInfo)
        textPremiumInfo = findViewById(R.id.textPremiumInfo)

        buttonPortuguese = findViewById(R.id.buttonPortuguese)
        buttonEnglish = findViewById(R.id.buttonEnglish)
        buttonSpanish = findViewById(R.id.buttonSpanish)
        buttonLogout = findViewById(R.id.buttonLogout)

        buttonPortuguese.setOnClickListener {
            saveLanguage("pt")
        }

        buttonEnglish.setOnClickListener {
            saveLanguage("en")
        }

        buttonSpanish.setOnClickListener {
            saveLanguage("es")
        }

        buttonLogout.setOnClickListener {
            logoutUser()
        }

        loadAccountInfo()
    }

    private fun loadAccountInfo() {
        val user = auth.currentUser

        if (user == null) {
            textAccountInfo.text = getString(R.string.no_session)
            textPremiumInfo.text = getString(R.string.account_no_session)
            return
        }

        textAccountInfo.text = getString(R.string.loading_account)
        textPremiumInfo.text = getString(R.string.checking_premium)

        val uid = user.uid
        val email = user.email ?: ""

        db.collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { document ->

                val name = document.getString("name") ?: getString(R.string.default_user)
                val isPremium = document.getBoolean("isPremium") ?: false

                db.collection("ads")
                    .whereEqualTo("ownerId", uid)
                    .get()
                    .addOnSuccessListener { adsResult ->

                        val adsCount = adsResult.size()

                        db.collection("users")
                            .document(uid)
                            .collection("favorites")
                            .get()
                            .addOnSuccessListener { favoritesResult ->

                                val favoritesCount = favoritesResult.size()

                                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)
                                val language = sharedPreferences.getString("language", "pt") ?: "pt"

                                textAccountInfo.text =
                                    "${getString(R.string.name_text)}: $name\n" +
                                            "${getString(R.string.email_text)}: $email\n" +
                                            "${getString(R.string.current_language)}: $language\n" +
                                            "${getString(R.string.ads_created_count)}: $adsCount\n" +
                                            "${getString(R.string.favorites_saved_count)}: $favoritesCount"

                                if (isPremium) {
                                    textPremiumInfo.text = getString(R.string.account_premium_active)
                                } else {
                                    textPremiumInfo.text = getString(R.string.account_free)
                                }
                            }
                            .addOnFailureListener {
                                textAccountInfo.text =
                                    "${getString(R.string.name_text)}: $name\n" +
                                            "${getString(R.string.email_text)}: $email"

                                if (isPremium) {
                                    textPremiumInfo.text = getString(R.string.account_premium_active)
                                } else {
                                    textPremiumInfo.text = getString(R.string.account_free)
                                }
                            }
                    }
            }
            .addOnFailureListener {
                textAccountInfo.text = getString(R.string.load_data_error)
                textPremiumInfo.text = getString(R.string.account_free)
            }
    }

    private fun saveLanguage(language: String) {
        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

        sharedPreferences.edit()
            .putString("language", language)
            .apply()

        Toast.makeText(
            this,
            getString(R.string.language_saved),
            Toast.LENGTH_SHORT
        ).show()

        recreate()
    }

    private fun logoutUser() {
        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"

        FirebaseAuth.getInstance().signOut()

        sharedPreferences.edit()
            .clear()
            .putString("language", language)
            .apply()

        Toast.makeText(
            this,
            getString(R.string.logout_success),
            Toast.LENGTH_SHORT
        ).show()

        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}