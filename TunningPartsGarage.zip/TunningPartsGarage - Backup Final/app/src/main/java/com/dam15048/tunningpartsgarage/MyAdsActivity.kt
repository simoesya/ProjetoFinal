package com.dam15048.tunningpartsgarage

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.app.Activity
import androidx.activity.result.contract.ActivityResultContracts

class MyAdsActivity : AppCompatActivity() {

    private lateinit var containerMyAds: LinearLayout
    private lateinit var textMyAdsInfo: TextView

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private val editAdLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val editedAdId = result.data?.getStringExtra("editedAdId")
            val editedAdTitle = result.data?.getStringExtra("editedAdTitle")

            loadMyAds()

            Toast.makeText(
                this,
                "Anúncio atualizado: $editedAdTitle",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_my_ads)

        containerMyAds = findViewById(R.id.containerMyAds)
        textMyAdsInfo = findViewById(R.id.textMyAdsInfo)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
    }

    override fun onResume() {
        super.onResume()
        loadMyAds()
    }

    private fun loadMyAds() {
        while (containerMyAds.childCount > 2) {
            containerMyAds.removeViewAt(2)
        }

        val currentUser = auth.currentUser

        if (currentUser == null) {
            textMyAdsInfo.text = getString(R.string.login_my_ads)
            return
        }

        textMyAdsInfo.text = getString(R.string.loading_my_ads)

        db.collection("ads")
            .whereEqualTo("ownerId", currentUser.uid)
            .get()
            .addOnSuccessListener { result ->
                while (containerMyAds.childCount > 2) {
                    containerMyAds.removeViewAt(2)
                }

                val ads = result.documents.mapNotNull { document ->
                    val ad = document.toObject(Ad::class.java)

                    if (ad != null) {
                        ad.id = document.id
                    }

                    ad
                }.sortedByDescending { ad ->
                    ad.createdAt
                }

                if (ads.isEmpty()) {
                    textMyAdsInfo.text = getString(R.string.no_my_ads)
                } else {
                    textMyAdsInfo.text = getString(R.string.my_ads_created)

                    for (ad in ads) {
                        createAdCard(ad)
                    }
                }
            }
            .addOnFailureListener { error ->
                textMyAdsInfo.text = getString(R.string.loading_my_ads)

                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun createAdCard(ad: Ad) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(0xFF333333.toInt())
        card.setPadding(16, 16, 16, 16)
        card.gravity = Gravity.CENTER

        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        cardParams.setMargins(0, 0, 0, 24)
        card.layoutParams = cardParams

        val textHighlighted = TextView(this)
        textHighlighted.text = getString(R.string.ad_highlighted)
        textHighlighted.setTextColor(0xFFFFD700.toInt())
        textHighlighted.textSize = 16f
        textHighlighted.setTypeface(null, android.graphics.Typeface.BOLD)
        textHighlighted.gravity = Gravity.CENTER
        textHighlighted.setPadding(0, 0, 0, 12)

        if (ad.highlighted) {
            textHighlighted.visibility = View.VISIBLE
        } else {
            textHighlighted.visibility = View.GONE
        }

        val imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.setBackgroundColor(0xFF222222.toInt())

        val imageParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            350
        )

        imageView.layoutParams = imageParams

        if (ad.imageUri != "no_image") {
            imageView.setImageURI(Uri.parse(ad.imageUri))
        } else {
            imageView.setImageResource(getImageForCategory(ad.categoryId))
        }

        val textView = TextView(this)
        textView.text =
            "${ad.title}\n" +
                    "${getString(R.string.price_text)}: ${ad.price}€\n" +
                    "${getString(R.string.location_text)}: ${ad.location}"

        textView.setTextColor(0xFFFFFFFF.toInt())
        textView.textSize = 16f
        textView.setPadding(0, 16, 0, 16)

        val buttonDetails = Button(this)
        buttonDetails.text = getString(R.string.view_details)
        buttonDetails.setBackgroundColor(0xFFFF3B3B.toInt())
        buttonDetails.setTextColor(0xFFFFFFFF.toInt())

        val buttonEdit = Button(this)
        buttonEdit.text = getString(R.string.edit)
        buttonEdit.setBackgroundColor(0xFF555555.toInt())
        buttonEdit.setTextColor(0xFFFFFFFF.toInt())

        val buttonHighlight = Button(this)

        if (ad.highlighted) {
            buttonHighlight.text = getString(R.string.ad_already_highlighted)
            buttonHighlight.setBackgroundColor(0xFF777777.toInt())
        } else {
            buttonHighlight.text = getString(R.string.highlight_ad)
            buttonHighlight.setBackgroundColor(0xFFFFD700.toInt())
        }

        buttonHighlight.setTextColor(0xFF000000.toInt())

        val buttonDelete = Button(this)
        buttonDelete.text = getString(R.string.delete_ad)
        buttonDelete.setBackgroundColor(0xFFAA0000.toInt())
        buttonDelete.setTextColor(0xFFFFFFFF.toInt())

        buttonDetails.setOnClickListener {
            showAdDetails(ad)
        }

        buttonEdit.setOnClickListener {
            val intent = Intent(this, EditAdActivity::class.java)
            intent.putExtra("adId", ad.id)
            editAdLauncher.launch(intent)
        }

        buttonHighlight.setOnClickListener {
            if (ad.highlighted) {
                Toast.makeText(
                    this,
                    getString(R.string.ad_already_highlighted),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                highlightAd(ad)
            }
        }

        buttonDelete.setOnClickListener {
            confirmDeleteAd(ad)
        }

        card.addView(textHighlighted)
        card.addView(imageView)
        card.addView(textView)
        card.addView(buttonDetails)
        card.addView(buttonEdit)
        card.addView(buttonHighlight)
        card.addView(buttonDelete)

        containerMyAds.addView(card)
    }

    private fun showAdDetails(ad: Ad) {
        val highlightedText = if (ad.highlighted) {
            getString(R.string.yes_text)
        } else {
            getString(R.string.no_text)
        }

        val message =
            "${getString(R.string.category_label)}: ${getCategoryNameFromId(ad.categoryId)}\n\n" +
                    "${getString(R.string.description_hint)}:\n${ad.description}\n\n" +
                    "${getString(R.string.price_text)}: ${ad.price}€\n\n" +
                    "${getString(R.string.location_text)}: ${ad.location}\n\n" +
                    "${getString(R.string.contact_text)}: ${ad.phone}\n\n" +
                    "${getString(R.string.highlighted_text)}: $highlightedText"

        AlertDialog.Builder(this)
            .setTitle(ad.title)
            .setMessage(message)
            .setPositiveButton(getString(R.string.close), null)
            .show()
    }

    private fun highlightAd(ad: Ad) {
        if (ad.id.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.ad_without_id),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        db.collection("ads")
            .document(ad.id)
            .update("highlighted", true)
            .addOnSuccessListener {
                Toast.makeText(
                    this,
                    getString(R.string.ad_highlighted_success),
                    Toast.LENGTH_LONG
                ).show()

                loadMyAds()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun confirmDeleteAd(ad: Ad) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_ad_title))
            .setMessage(getString(R.string.delete_ad_question))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                deleteAd(ad)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun deleteAd(ad: Ad) {
        db.collection("ads")
            .document(ad.id)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(
                    this,
                    getString(R.string.ad_deleted_success),
                    Toast.LENGTH_SHORT
                ).show()

                loadMyAds()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun getImageForCategory(categoryId: String): Int {
        return when (categoryId) {
            "wheels" -> R.drawable.jantes
            "suspension" -> R.drawable.suspensao
            "exhaust" -> R.drawable.escape
            "brakes" -> R.drawable.travoes
            "engine" -> R.drawable.motor
            "lights" -> R.drawable.luzes
            "interior" -> R.drawable.interior
            "bodykits" -> R.drawable.bodykit
            else -> R.drawable.jantes
        }
    }

    private fun getCategoryNameFromId(categoryId: String): String {
        return when (categoryId) {
            "wheels" -> getString(R.string.cat_wheels)
            "suspension" -> getString(R.string.cat_suspension)
            "exhaust" -> getString(R.string.cat_exhaust)
            "brakes" -> getString(R.string.cat_brakes)
            "engine" -> getString(R.string.cat_engine)
            "lights" -> getString(R.string.cat_lights)
            "interior" -> getString(R.string.cat_interior)
            "bodykits" -> getString(R.string.cat_bodykits)
            else -> getString(R.string.category_label)
        }
    }
}