package com.dam15048.tunningpartsgarage

import android.app.Activity
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.util.Locale

class MapPickerActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private lateinit var buttonConfirmLocation: Button

    private var selectedLatLng: LatLng? = null

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_picker)

        buttonConfirmLocation = findViewById(R.id.buttonConfirmLocation)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapFragment) as SupportMapFragment

        mapFragment.getMapAsync(this)

        buttonConfirmLocation.setOnClickListener {
            confirmLocation()
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        val portugal = LatLng(39.3999, -8.2245)

        googleMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(portugal, 6.5f)
        )

        googleMap.setOnMapClickListener { latLng ->
            selectedLatLng = latLng

            googleMap.clear()

            googleMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title(getString(R.string.selected_location))
            )

            googleMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(latLng, 14f)
            )
        }
    }

    private fun confirmLocation() {
        val location = selectedLatLng

        if (location == null) {
            Toast.makeText(
                this,
                getString(R.string.select_location_first),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val locationName = getApproxLocationName(
            location.latitude,
            location.longitude
        )

        val resultIntent = Intent()
        resultIntent.putExtra("latitude", location.latitude)
        resultIntent.putExtra("longitude", location.longitude)
        resultIntent.putExtra("locationName", locationName)

        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    @Suppress("DEPRECATION")
    private fun getApproxLocationName(latitude: Double, longitude: Double): String {
        return try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)

            if (addresses.isNullOrEmpty()) {
                getString(R.string.map_selected_location_generic)
            } else {
                val address = addresses[0]

                val city = address.locality
                val municipality = address.subAdminArea
                val district = address.adminArea
                val country = address.countryName

                val parts = mutableListOf<String>()

                if (!city.isNullOrBlank()) {
                    parts.add(city)
                } else if (!municipality.isNullOrBlank()) {
                    parts.add(municipality)
                }

                if (!district.isNullOrBlank() && district != city) {
                    parts.add(district)
                }

                if (!country.isNullOrBlank()) {
                    parts.add(country)
                }

                if (parts.isEmpty()) {
                    getString(R.string.map_selected_location_generic)
                } else {
                    parts.joinToString(", ")
                }
            }
        } catch (e: Exception) {
            getString(R.string.map_selected_location_generic)
        }
    }
}