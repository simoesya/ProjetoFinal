package com.dam15048.tunningpartsgarage

object MockData {

    val categories = listOf(
        Category("wheels", "Jantes"),
        Category("suspension", "Suspensões"),
        Category("exhaust", "Escapes"),
        Category("brakes", "Travões"),
        Category("engine", "Motor"),
        Category("lights", "Iluminação"),
        Category("interior", "Interior"),
        Category("bodykits", "Body Kits")
    )

    // Agora cada Part representa um anúncio de marketplace.
    // Exemplo: um utilizador publica uma peça tuning para venda.
    val parts = listOf(
        Part(
            id = "p1",
            name = "Jantes Japan Racing 18",
            categoryId = "wheels",
            description = "Jantes usadas em bom estado. Ideais para projeto tuning ou carro rebaixado.",
            price = 650.00,
            isPremium = false,
            sellerName = "Miguel Santos",
            location = "Lisboa",
            phone = "912345678",
            isHighlighted = true
        ),
        Part(
            id = "p2",
            name = "Jantes BBS 17",
            categoryId = "wheels",
            description = "Conjunto de 4 jantes BBS. Pequenas marcas de uso, mas sem empenos.",
            price = 900.00,
            isPremium = true,
            sellerName = "Rui Almeida",
            location = "Sintra",
            phone = "934567890",
            isHighlighted = false
        ),
        Part(
            id = "p3",
            name = "Coilovers Street Performance",
            categoryId = "suspension",
            description = "Suspensão ajustável usada durante 6 meses. Boa para baixar o carro.",
            price = 420.00,
            isPremium = false,
            sellerName = "João Martins",
            location = "Loures",
            phone = "965432187",
            isHighlighted = true
        ),
        Part(
            id = "p4",
            name = "Suspensão Air Ride",
            categoryId = "suspension",
            description = "Kit Air Ride completo para projeto show car. Material premium.",
            price = 1500.00,
            isPremium = true,
            sellerName = "Pedro Costa",
            location = "Porto",
            phone = "918765432",
            isHighlighted = false
        ),
        Part(
            id = "p5",
            name = "Escape Desportivo Inox",
            categoryId = "exhaust",
            description = "Escape em inox com som agressivo. Compatível com vários modelos.",
            price = 280.00,
            isPremium = false,
            sellerName = "Carlos Ferreira",
            location = "Almada",
            phone = "913214567",
            isHighlighted = false
        ),
        Part(
            id = "p6",
            name = "Escape Titanium Premium",
            categoryId = "exhaust",
            description = "Escape em titânio, leve e com acabamento de competição.",
            price = 850.00,
            isPremium = true,
            sellerName = "André Lopes",
            location = "Cascais",
            phone = "926789123",
            isHighlighted = true
        ),
        Part(
            id = "p7",
            name = "Kit Travões Performance",
            categoryId = "brakes",
            description = "Discos e pastilhas performance. Ideal para condução mais desportiva.",
            price = 390.00,
            isPremium = false,
            sellerName = "Tiago Rocha",
            location = "Odivelas",
            phone = "935678111",
            isHighlighted = false
        ),
        Part(
            id = "p8",
            name = "Filtro de Ar Desportivo",
            categoryId = "engine",
            description = "Filtro de ar desportivo usado, em bom estado.",
            price = 70.00,
            isPremium = false,
            sellerName = "Bruno Silva",
            location = "Amadora",
            phone = "967111222",
            isHighlighted = false
        ),
        Part(
            id = "p9",
            name = "Faróis LED Tuning",
            categoryId = "lights",
            description = "Faróis LED com visual moderno. Vendo por troca de projeto.",
            price = 220.00,
            isPremium = false,
            sellerName = "Nuno Pereira",
            location = "Setúbal",
            phone = "912222333",
            isHighlighted = true
        ),
        Part(
            id = "p10",
            name = "Volante Racing",
            categoryId = "interior",
            description = "Volante racing em ótimo estado. Inclui cubo adaptador.",
            price = 150.00,
            isPremium = false,
            sellerName = "Diogo Fernandes",
            location = "Vila Franca de Xira",
            phone = "934444555",
            isHighlighted = false
        ),
        Part(
            id = "p11",
            name = "Kit Para-choques e Spoiler",
            categoryId = "bodykits",
            description = "Body kit completo com para-choques frontal, traseiro e spoiler.",
            price = 600.00,
            isPremium = false,
            sellerName = "Ricardo Moreira",
            location = "Leiria",
            phone = "968888777",
            isHighlighted = true
        )
    )
}