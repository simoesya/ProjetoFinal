package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonRegister: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        editEmail = findViewById(R.id.editEmail)
        editPassword = findViewById(R.id.editPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonRegister = findViewById(R.id.buttonRegister)

        buttonLogin.setOnClickListener {
            loginUser()
        }

        buttonRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loginUser() {
        val email = editEmail.text.toString().trim()
        val password = editPassword.text.toString().trim()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.fill_email_password),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                val user = auth.currentUser

                if (user != null) {
                    loadUserData(user.uid, email)
                }
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "${getString(R.string.login_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun loadUserData(uid: String, email: String) {
        db.collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { document ->
                val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)

                if (document.exists()) {
                    val name = document.getString("name") ?: getString(R.string.default_user)
                    val isPremium = document.getBoolean("isPremium") ?: false

                    sharedPreferences.edit()
                        .putString("userId", uid)
                        .putString("userName", name)
                        .putString("userEmail", email)
                        .putBoolean("isPremium", isPremium)
                        .apply()
                } else {
                    sharedPreferences.edit()
                        .putString("userId", uid)
                        .putString("userName", getString(R.string.default_user))
                        .putString("userEmail", email)
                        .putBoolean("isPremium", false)
                        .apply()
                }

                Toast.makeText(
                    this,
                    getString(R.string.login_success),
                    Toast.LENGTH_SHORT
                ).show()

                val intent = Intent(this, MainMenuActivity::class.java)
                intent.putExtra("userEmail", email)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "${getString(R.string.load_data_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}