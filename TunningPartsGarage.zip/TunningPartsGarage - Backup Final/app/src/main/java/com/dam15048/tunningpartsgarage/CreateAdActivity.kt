package com.dam15048.tunningpartsgarage

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CreateAdActivity : AppCompatActivity() {

    private lateinit var imageAdPreview: ImageView
    private lateinit var buttonChooseImage: Button
    private lateinit var buttonChooseLocationMap: Button
    private lateinit var editAdTitle: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var editAdDescription: EditText
    private lateinit var editAdPrice: EditText
    private lateinit var editAdLocation: EditText
    private lateinit var editAdPhone: EditText
    private lateinit var buttonPublishAd: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private var selectedImageUri: Uri? = null
    private var selectedLatitude: Double? = null
    private var selectedLongitude: Double? = null

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            imageAdPreview.setImageURI(uri)
            imageAdPreview.setPadding(0, 0, 0, 0)
        }
    }

    private val mapPicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val latitude = result.data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val longitude = result.data?.getDoubleExtra("longitude", 0.0) ?: 0.0
            val locationName = result.data?.getStringExtra("locationName")
                ?: getString(R.string.map_selected_location_generic)

            selectedLatitude = latitude
            selectedLongitude = longitude

            editAdLocation.setText(locationName)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_create_ad)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        imageAdPreview = findViewById(R.id.imageAdPreview)
        buttonChooseImage = findViewById(R.id.buttonChooseImage)
        buttonChooseLocationMap = findViewById(R.id.buttonChooseLocationMap)
        editAdTitle = findViewById(R.id.editAdTitle)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        editAdDescription = findViewById(R.id.editAdDescription)
        editAdPrice = findViewById(R.id.editAdPrice)
        editAdLocation = findViewById(R.id.editAdLocation)
        editAdPhone = findViewById(R.id.editAdPhone)
        buttonPublishAd = findViewById(R.id.buttonPublishAd)

        setupCategorySpinner()

        buttonChooseImage.setOnClickListener {
            imagePicker.launch("image/*")
        }

        buttonChooseLocationMap.setOnClickListener {
            val intent = Intent(this, MapPickerActivity::class.java)
            mapPicker.launch(intent)
        }

        buttonPublishAd.setOnClickListener {
            publishAd()
        }
    }

    private fun setupCategorySpinner() {
        val categories = listOf(
            getString(R.string.choose_category),
            getString(R.string.cat_wheels),
            getString(R.string.cat_suspension),
            getString(R.string.cat_exhaust),
            getString(R.string.cat_brakes),
            getString(R.string.cat_engine),
            getString(R.string.cat_lights),
            getString(R.string.cat_interior),
            getString(R.string.cat_bodykits)
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            categories
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = adapter
    }

    private fun publishAd() {
        val title = editAdTitle.text.toString().trim()
        val selectedCategory = spinnerCategory.selectedItem.toString()
        val categoryId = getCategoryId(selectedCategory)
        val description = editAdDescription.text.toString().trim()
        val price = editAdPrice.text.toString().trim()
        val location = editAdLocation.text.toString().trim()
        val phone = editAdPhone.text.toString().trim()
        val imageUriText = selectedImageUri?.toString() ?: "no_image"

        if (
            title.isEmpty() ||
            selectedCategory == getString(R.string.choose_category) ||
            description.isEmpty() ||
            price.isEmpty() ||
            location.isEmpty() ||
            phone.isEmpty()
        ) {
            Toast.makeText(
                this,
                getString(R.string.fill_all_fields),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val currentUser = auth.currentUser

        if (currentUser == null) {
            Toast.makeText(
                this,
                getString(R.string.login_required),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        buttonPublishAd.isEnabled = false
        buttonPublishAd.text = getString(R.string.publishing)

        val sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE)
        val ownerName = sharedPreferences.getString(
            "userName",
            currentUser.email ?: getString(R.string.default_user)
        ) ?: getString(R.string.default_user)

        val documentReference = db.collection("ads").document()

        val adData = hashMapOf<String, Any>(
            "id" to documentReference.id,
            "title" to title,
            "categoryId" to categoryId,
            "description" to description,
            "price" to price,
            "location" to location,
            "phone" to phone,
            "imageUri" to imageUriText,
            "ownerId" to currentUser.uid,
            "ownerName" to ownerName,
            "highlighted" to false,
            "createdAt" to System.currentTimeMillis()
        )

        if (selectedLatitude != null && selectedLongitude != null) {
            adData["latitude"] = selectedLatitude!!
            adData["longitude"] = selectedLongitude!!
        }

        documentReference.set(adData)
            .addOnSuccessListener {
                Toast.makeText(
                    this,
                    getString(R.string.ad_published_success),
                    Toast.LENGTH_SHORT
                ).show()

                setResult(Activity.RESULT_OK)
                finish()
            }
            .addOnFailureListener { error ->
                buttonPublishAd.isEnabled = true
                buttonPublishAd.text = getString(R.string.publish_ad)

                Toast.makeText(
                    this,
                    "${getString(R.string.publish_ad_error)}: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun getCategoryId(categoryName: String): String {
        return when (categoryName) {
            getString(R.string.cat_wheels) -> "wheels"
            getString(R.string.cat_suspension) -> "suspension"
            getString(R.string.cat_exhaust) -> "exhaust"
            getString(R.string.cat_brakes) -> "brakes"
            getString(R.string.cat_engine) -> "engine"
            getString(R.string.cat_lights) -> "lights"
            getString(R.string.cat_interior) -> "interior"
            getString(R.string.cat_bodykits) -> "bodykits"
            else -> ""
        }
    }
}