package com.dam15048.tunningpartsgarage

data class Category(
    val id: String,
    val name: String
)