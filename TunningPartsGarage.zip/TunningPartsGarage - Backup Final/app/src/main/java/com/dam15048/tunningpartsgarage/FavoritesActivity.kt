package com.dam15048.tunningpartsgarage

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FavoritesActivity : AppCompatActivity() {

    private lateinit var containerFavorites: LinearLayout
    private lateinit var textFavoritesInfo: TextView

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_favorites)

        containerFavorites = findViewById(R.id.containerFavorites)
        textFavoritesInfo = findViewById(R.id.textFavoritesInfo)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun loadFavorites() {
        while (containerFavorites.childCount > 2) {
            containerFavorites.removeViewAt(2)
        }

        val currentUser = auth.currentUser

        if (currentUser == null) {
            textFavoritesInfo.text = getString(R.string.login_favorites)
            return
        }

        textFavoritesInfo.text = getString(R.string.loading_favorites)

        db.collection("users")
            .document(currentUser.uid)
            .collection("favorites")
            .get()
            .addOnSuccessListener { result ->
                while (containerFavorites.childCount > 2) {
                    containerFavorites.removeViewAt(2)
                }

                if (result.isEmpty) {
                    textFavoritesInfo.text = getString(R.string.no_favorites)
                    return@addOnSuccessListener
                }

                textFavoritesInfo.text = getString(R.string.favorites_saved)

                for (document in result) {
                    val adId = document.getString("adId") ?: document.id
                    loadAdById(adId)
                }
            }
            .addOnFailureListener { error ->
                textFavoritesInfo.text = getString(R.string.no_favorites)

                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun loadAdById(adId: String) {
        db.collection("ads")
            .document(adId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val ad = document.toObject(Ad::class.java)

                    if (ad != null) {
                        ad.id = document.id
                        createFavoriteCard(ad)
                    }
                }
            }
    }

    private fun createFavoriteCard(ad: Ad) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(0xFF333333.toInt())
        card.setPadding(16, 16, 16, 16)
        card.gravity = Gravity.CENTER

        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        cardParams.setMargins(0, 0, 0, 24)
        card.layoutParams = cardParams

        val imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.setBackgroundColor(0xFF222222.toInt())

        val imageParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            350
        )
        imageView.layoutParams = imageParams

        if (ad.imageUri != "no_image") {
            imageView.setImageURI(Uri.parse(ad.imageUri))
        } else {
            imageView.setImageResource(getImageForCategory(ad.categoryId))
        }

        val textView = TextView(this)
        textView.text =
            "${ad.title}\n" +
                    "${getString(R.string.price_text)}: ${ad.price}€\n" +
                    "${getString(R.string.location_text)}: ${ad.location}\n" +
                    "${getString(R.string.seller_text)}: ${ad.ownerName}"

        textView.setTextColor(0xFFFFFFFF.toInt())
        textView.textSize = 16f
        textView.setPadding(0, 16, 0, 16)

        val buttonOpen = Button(this)
        buttonOpen.text = getString(R.string.view_ad)
        buttonOpen.setBackgroundColor(0xFFFF3B3B.toInt())
        buttonOpen.setTextColor(0xFFFFFFFF.toInt())

        val buttonRemove = Button(this)
        buttonRemove.text = getString(R.string.remove_favorite)
        buttonRemove.setBackgroundColor(0xFFAA0000.toInt())
        buttonRemove.setTextColor(0xFFFFFFFF.toInt())

        buttonOpen.setOnClickListener {
            showAdDetails(ad)
        }

        buttonRemove.setOnClickListener {
            removeFavorite(ad)
        }

        card.addView(imageView)
        card.addView(textView)
        card.addView(buttonOpen)
        card.addView(buttonRemove)

        containerFavorites.addView(card)
    }

    private fun showAdDetails(ad: Ad) {
        val highlightedText = if (ad.highlighted) {
            getString(R.string.yes_text)
        } else {
            getString(R.string.no_text)
        }

        val message =
            "${getString(R.string.category_label)}: ${getCategoryNameFromId(ad.categoryId)}\n\n" +
                    "${getString(R.string.description_hint)}:\n${ad.description}\n\n" +
                    "${getString(R.string.price_text)}: ${ad.price}€\n\n" +
                    "${getString(R.string.location_text)}: ${ad.location}\n\n" +
                    "${getString(R.string.seller_text)}: ${ad.ownerName}\n\n" +
                    "${getString(R.string.contact_text)}: ${ad.phone}\n\n" +
                    "${getString(R.string.highlighted_text)}: $highlightedText"

        AlertDialog.Builder(this)
            .setTitle(ad.title)
            .setMessage(message)
            .setPositiveButton(getString(R.string.close), null)
            .show()
    }

    private fun removeFavorite(ad: Ad) {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            return
        }

        db.collection("users")
            .document(currentUser.uid)
            .collection("favorites")
            .document(ad.id)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(
                    this,
                    getString(R.string.favorite_removed),
                    Toast.LENGTH_SHORT
                ).show()

                loadFavorites()
            }
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "Erro: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun getImageForCategory(categoryId: String): Int {
        return when (categoryId) {
            "wheels" -> R.drawable.jantes
            "suspension" -> R.drawable.suspensao
            "exhaust" -> R.drawable.escape
            "brakes" -> R.drawable.travoes
            "engine" -> R.drawable.motor
            "lights" -> R.drawable.luzes
            "interior" -> R.drawable.interior
            "bodykits" -> R.drawable.bodykit
            else -> R.drawable.jantes
        }
    }

    private fun getCategoryNameFromId(categoryId: String): String {
        return when (categoryId) {
            "wheels" -> getString(R.string.cat_wheels)
            "suspension" -> getString(R.string.cat_suspension)
            "exhaust" -> getString(R.string.cat_exhaust)
            "brakes" -> getString(R.string.cat_brakes)
            "engine" -> getString(R.string.cat_engine)
            "lights" -> getString(R.string.cat_lights)
            "interior" -> getString(R.string.cat_interior)
            "bodykits" -> getString(R.string.cat_bodykits)
            else -> getString(R.string.category_label)
        }
    }
}