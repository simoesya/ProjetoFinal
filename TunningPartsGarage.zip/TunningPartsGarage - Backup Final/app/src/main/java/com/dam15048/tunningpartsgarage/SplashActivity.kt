package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<ImageView>(R.id.imageLogo)
        val title = findViewById<TextView>(R.id.textAppName)
        val subtitle = findViewById<TextView>(R.id.textSubtitle)

        val logoAnimation = AnimationUtils.loadAnimation(this, R.anim.splash_logo)
        val textAnimation = AnimationUtils.loadAnimation(this, R.anim.splash_text)

        logo.startAnimation(logoAnimation)
        title.startAnimation(textAnimation)
        subtitle.startAnimation(textAnimation)

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 2200)
    }
}