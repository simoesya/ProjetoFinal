package com.dam15048.tunningpartsgarage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class CategoriesActivity : AppCompatActivity() {

    private lateinit var containerCategories: LinearLayout

    override fun attachBaseContext(newBase: android.content.Context) {
        val sharedPreferences = newBase.getSharedPreferences("app_data", MODE_PRIVATE)
        val language = sharedPreferences.getString("language", "pt") ?: "pt"
        super.attachBaseContext(LocaleHelper.setLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_categories)

        containerCategories = findViewById(R.id.containerCategories)

        for (category in MockData.categories) {
            val button = Button(this)

            val translatedCategoryName = getTranslatedCategoryName(category.id)

            button.text = translatedCategoryName
            button.setBackgroundColor(0xFFFF3B3B.toInt())
            button.setTextColor(0xFFFFFFFF.toInt())

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

            params.setMargins(0, 0, 0, 20)
            button.layoutParams = params

            button.setOnClickListener {
                val intent = Intent(this, PartsListActivity::class.java)
                intent.putExtra("categoryId", category.id)
                intent.putExtra("categoryName", translatedCategoryName)
                startActivity(intent)
            }

            containerCategories.addView(button)
        }
    }

    private fun getTranslatedCategoryName(categoryId: String): String {
        return when (categoryId) {
            "wheels" -> getString(R.string.cat_wheels)
            "suspension" -> getString(R.string.cat_suspension)
            "exhaust" -> getString(R.string.cat_exhaust)
            "brakes" -> getString(R.string.cat_brakes)
            "engine" -> getString(R.string.cat_engine)
            "lights" -> getString(R.string.cat_lights)
            "interior" -> getString(R.string.cat_interior)
            "bodykits" -> getString(R.string.cat_bodykits)
            else -> categoryId
        }
    }
}