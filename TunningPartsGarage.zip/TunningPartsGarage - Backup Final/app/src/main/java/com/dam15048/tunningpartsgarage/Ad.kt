package com.dam15048.tunningpartsgarage

data class Ad(
    var id: String = "",
    var title: String = "",
    var categoryId: String = "",
    var description: String = "",
    var price: String = "",
    var location: String = "",
    var phone: String = "",
    var imageUri: String = "no_image",
    var ownerId: String = "",
    var ownerName: String = "",
    var highlighted: Boolean = false,
    var createdAt: Long = System.currentTimeMillis()
)